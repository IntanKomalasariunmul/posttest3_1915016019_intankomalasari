package com.example.posttest3_1915016019_intankomalasari

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
