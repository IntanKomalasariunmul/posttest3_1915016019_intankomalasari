import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'posttest3_1915016019_intankomalasari',
      theme: ThemeData(
        // Define the default brightness and colors.
        brightness: Brightness.dark,
        primaryColor: Colors.lightBlue[800],

        // Define the default font family.
        fontFamily: 'Georgia',

        // Define the default TextTheme. Use this to specify the default
        // text styling for headlines, titles, bodies of text, and more.
        textTheme: TextTheme(
          headline1: TextStyle(fontSize: 72.0, fontWeight: FontWeight.bold),
          headline6: TextStyle(fontSize: 36.0, fontStyle: FontStyle.italic),
          bodyText2: TextStyle(fontSize: 14.0, fontFamily: 'Hind'),
        ),
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

enum Ukg { unknown, tall, grande, venti }

class _MyHomePageState extends State<MyHomePage> {
  final namaDepanCtrl = TextEditingController();
  final namaBelakangCtrl = TextEditingController();
  Ukg ukg = Ukg.unknown;

  bool isBrewedcoffee = false;
  bool isEspressobeverages = false;
  String namaDepan = "", namaBelakang = '';

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    namaDepanCtrl.dispose();
    namaBelakangCtrl.dispose();
    super.dispose();
  }

  String getUkg(Ukg? value) {
    if (value == Ukg.tall) {
      return "Tall";
    } else if (value == Ukg.grande) {
      return "Grande";
    } else if (value == Ukg.venti) {
      return "Venti";
    }
    return "";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: GestureDetector(
          onTap: () {/* Write listener code here */},
          child: Icon(
            Icons.menu, // add custom icons also
          ),
        ),
        title: Text('Coffee Shop'),
        flexibleSpace: Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: <Color>[
                Color.fromARGB(255, 255, 140, 25),
                Color.fromARGB(255, 243, 172, 7)
              ])),
        ),
      ),
      backgroundColor: Color.fromARGB(255, 242, 172, 74),
      body: ListView(
        children: [
          Container(
            width: 192,
            height: 243,
            margin: EdgeInsets.only(top: 61),
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/image2.png"),
              ),
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text('Nama Pemesan $namaDepan $namaBelakang'),
              Text('Ukuran Gelas ${getUkg(ukg)} '),
              Text(
                  'Menu ${isBrewedcoffee ? "Brewedcoffee" : "Espressobeverages"}'),
              const SizedBox(height: 20), // Margin Bohongan
              TextField(
                maxLines: 4,
                controller: namaDepanCtrl,
                decoration: new InputDecoration(
                  contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                  border: OutlineInputBorder(
                      borderRadius: new BorderRadius.circular(2.0)),
                  icon: Icon(Icons.people),
                  labelText: "Nama Depan",
                  hintText: 'Nama Depan',
                ),
              ),
              const SizedBox(height: 20), // Margin Bohongan
              TextFormField(
                maxLines: 2,
                controller: namaBelakangCtrl,
                decoration: new InputDecoration(
                    contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
                    border: OutlineInputBorder(
                        borderRadius: new BorderRadius.circular(2.0)),
                    icon: Icon(Icons.people),
                    hintText: 'Nama Belakang',
                    labelText: "Nama Belakang"),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: ListTile(
                      title: const Text("Tall (354 ml)"),
                      leading: Radio(
                        groupValue: ukg,
                        value: Ukg.tall,
                        onChanged: (Ukg? value) {
                          setState(() {
                            ukg = value!;
                          });
                        },
                      ),
                    ),
                  ),
                  Expanded(
                    child: ListTile(
                      title: const Text("Grande (473 ml)"),
                      leading: Radio(
                        groupValue: ukg,
                        value: Ukg.grande,
                        onChanged: (Ukg? value) {
                          setState(() {
                            ukg = value!;
                          });
                        },
                      ),
                    ),
                  ),
                  Expanded(
                    child: ListTile(
                      title: const Text("Venti (591 ml)"),
                      leading: Radio(
                        groupValue: ukg,
                        value: Ukg.venti,
                        onChanged: (Ukg? value) {
                          setState(() {
                            ukg = value!;
                          });
                        },
                      ),
                    ),
                  ),
                ],
              ),
              ListTile(
                title: const Text("Brewedcoffee?"),
                leading: Checkbox(
                  value: isBrewedcoffee,
                  onChanged: (bool? value) {
                    setState(() {
                      isBrewedcoffee = value!;
                    });
                  },
                ),
              ),
              ListTile(
                title: const Text("Espressobeverages?"),
                leading: Checkbox(
                  value: isEspressobeverages,
                  onChanged: (bool? value) {
                    setState(() {
                      isEspressobeverages = value!;
                    });
                  },
                ),
              ),
            ],
          ),
          ElevatedButton(
            style: ButtonStyle(
              padding: MaterialStateProperty.resolveWith((states) {
                return const EdgeInsets.symmetric(horizontal: 18, vertical: 8);
              }),
              backgroundColor: MaterialStateColor.resolveWith((states) {
                return const Color.fromARGB(255, 254, 89, 29);
              }),
              shape: MaterialStateProperty.resolveWith((states) {
                return StadiumBorder();
              }),
            ),
            onPressed: () {
              final snackBar = SnackBar(
                content: Text('Pesanan Diproses (Intan Komalasari)'),
                action: SnackBarAction(
                  label: 'Undo',
                  onPressed: () {
                    // Some code to undo the change.
                  },
                ),
              );
              ScaffoldMessenger.of(context).showSnackBar(snackBar);
              setState(() {
                namaDepan = namaDepanCtrl.text;
                namaBelakang = namaBelakangCtrl.text;
              });
            },
            child: Text(
              'Pesan Sekarang',
              style: TextStyle(
                fontSize: 20,
              ),
            ),
          ),
          SizedBox(
            height: 30,
          ),
        ],
      ),
    );
  }
}
